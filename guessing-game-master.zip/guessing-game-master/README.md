Guessing Game!

Guess a number between 1 and 100! How many guesses will it take you? Created
as a project for Fullstack Academy!

Please visit at:
http://tmkelly28.github.io/guessing-game/guessing_game_index.html
